#!/bin/bash
# start nginx

rm -rf /app/magento/emimall-uat/app
