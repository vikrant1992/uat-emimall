#!/bin/bash
#getting status
service nginx restart
service nginx status
